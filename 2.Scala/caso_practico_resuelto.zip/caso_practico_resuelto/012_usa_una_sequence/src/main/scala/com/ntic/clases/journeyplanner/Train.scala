package com.ntic.clases.journeyplanner
case class Train(kind: String, number: Int, schedule: Seq[Station]) {
  require(schedule.size >= 2, "schedule debe tener al menos dos elementos")
}
case class Station(name: String)

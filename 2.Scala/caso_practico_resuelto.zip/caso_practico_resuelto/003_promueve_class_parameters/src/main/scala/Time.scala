class Time(val hours: Int, val minutes: Int) {
  // TODO `hours` entre  0 y 23
  // TODO `minutes` entre 0 y 59
}

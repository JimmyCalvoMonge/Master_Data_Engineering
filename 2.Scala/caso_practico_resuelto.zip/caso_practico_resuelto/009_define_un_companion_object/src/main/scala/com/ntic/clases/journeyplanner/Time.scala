package com.ntic.clases.journeyplanner
object Time {
  def fromMinutes(minutes: Int): Time =
    new Time(minutes / 60, minutes % 60)
}
class Time(val hours: Int = 0, val minutes: Int = 0) {
  // TODO `hours` entre 0 y 23
  // TODO `minutes` entre 0 y 59
  val asMinutes: Int =
    hours * 60 + minutes
  def minus(that: Time): Int =
    this.asMinutes - that.asMinutes
  def -(that: Time): Int =
    minus(that)
}

package com.ntic.clases.journeyplanner
case class Train(kind: String, number: Int, schedule: Seq[(Time, Station)]) {
  require(schedule.size >= 2, "schedule debe tener al menos dos elementos")
  val stations: Seq[Station] =
    schedule.map(stop => stop._2)
}
case class Station(name: String)

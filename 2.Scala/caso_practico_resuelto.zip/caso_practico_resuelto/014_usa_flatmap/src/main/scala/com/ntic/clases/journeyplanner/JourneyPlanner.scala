package com.ntic.clases.journeyplanner
class JourneyPlanner(trains: Set[Train]) {
  val stations: Set[Station] =
    trains.flatMap(train => train.stations)
}

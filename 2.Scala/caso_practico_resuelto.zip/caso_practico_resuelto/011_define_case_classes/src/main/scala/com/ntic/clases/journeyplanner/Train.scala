package com.ntic.clases.journeyplanner
case class Train(kind: String, number: Int)

class Train(number: Int)

import com.ntic.clases.scalaTrain
class Time(val hours: Int = 0, val minutes: Int = 0) {
  // TODO `hours` entre 0 y 23
  // TODO `minutes` entre 0 y 59
  val asMinutes: Int =
    hours * 60 + minutes
  def minus(that: scalaTrain.Time): Int =
    this.asMinutes - that.asMinutes
  def -(that: scalaTrain.Time): Int =
    minus(that)
}

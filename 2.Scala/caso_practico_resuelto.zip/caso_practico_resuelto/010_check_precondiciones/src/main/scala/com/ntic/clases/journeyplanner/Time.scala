package com.ntic.clases.journeyplanner
object Time {
  def fromMinutes(minutes: Int): Time =
    new Time(minutes / 60, minutes % 60)
}
class Time(val hours: Int = 0, val minutes: Int = 0) {
  require(hours >= 0 && hours <= 23, "hours debe estar entre 0 y 23")
  require(minutes >= 0 && minutes <= 59, "minutes debe estar entre 0 y 59")
  val asMinutes: Int =
    hours * 60 + minutes
  def minus(that: Time): Int =
    this.asMinutes - that.asMinutes
  def -(that: Time): Int =
    minus(that)
}

package com.ntic.clases.journeyplanner
class JourneyPlanner(trains: Set[Train]) {
  val stations: Set[Station] =
    trains.flatMap(train => train.stations)
  def trainsAt(station: Station): Set[Train] =
    trains.filter(train => train.stations contains station)
}

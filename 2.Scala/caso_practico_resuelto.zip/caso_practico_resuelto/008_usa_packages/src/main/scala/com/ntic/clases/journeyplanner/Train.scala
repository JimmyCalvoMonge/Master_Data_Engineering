package com.ntic.clases.journeyplanner
class Train(val kind: String, val number: Int)

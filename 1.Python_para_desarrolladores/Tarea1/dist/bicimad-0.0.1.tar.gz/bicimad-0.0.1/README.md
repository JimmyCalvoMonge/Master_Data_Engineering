# Paquete bicimad

Implementa el módulo bicimad requerido por el enunciado de la tarea.
Autor: Jimmy Calvo-Monge
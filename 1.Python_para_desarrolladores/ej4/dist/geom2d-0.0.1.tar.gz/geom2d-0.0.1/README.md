# Paquete geom2d

Implementa las clases **Vector** y **Point** y efectúa operaciones geométricas con estos objetos.
